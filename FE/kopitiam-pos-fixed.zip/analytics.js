/**
 * ============================================================
 * KopiTiam POS — Analytics Dashboard (analytics.js) [FIXED]
 * Real-time insights dashboard with Chart.js
 * All event listeners attached after DOM ready
 * Data fetched from API with loading states & error handling
 * ============================================================
 */

// ── Configuration ───────────────────────────────────────────
const CONFIG = {
  API_BASE_URL: 'http://localhost:8080',
  TOKEN_KEY: 'kopitiam_token',
  USER_KEY: 'kopitiam_user',
  REFRESH_KEY: 'kopitiam_refresh_token',
};

// ── State ───────────────────────────────────────────────────
let salesChart = null;
let paymentChart = null;
let currentPeriod = '7D';
let isLoading = false;
let dateRange = { start: '', end: '' };
let autoRefreshInterval = null;
let retryCount = 0;
const MAX_RETRIES = 3;

// ── DOM Helpers ─────────────────────────────────────────────
const $ = (id) => document.getElementById(id);

// ── Config Loader ───────────────────────────────────────────
async function loadConfig() {
  try {
    const res = await fetch('./.env');
    if (res.ok) {
      const text = await res.text();
      text.split('\n').forEach(line => {
        const [key, val] = line.split('=');
        if (key === 'API_BASE_URL' && val) CONFIG.API_BASE_URL = val.trim();
      });
    }
  } catch (e) { /* fallback */ }
}

// ── Auth Check ──────────────────────────────────────────────
function checkAuth() {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const user = JSON.parse(localStorage.getItem(CONFIG.USER_KEY) || '{}');

  if (!token) {
    window.location.href = './index.html';
    return false;
  }

  // Populate user info
  if (user.name) {
    const userNameEl = $('user-name');
    const userRoleEl = $('user-role');
    const userInitialEl = $('user-initial');
    if (userNameEl) userNameEl.textContent = user.name;
    if (userRoleEl) userRoleEl.textContent = user.role || 'Manager';
    if (userInitialEl) userInitialEl.textContent = (user.name || 'M').charAt(0).toUpperCase();
  }

  return token;
}

function logout() {
  localStorage.removeItem(CONFIG.TOKEN_KEY);
  localStorage.removeItem(CONFIG.REFRESH_KEY);
  localStorage.removeItem(CONFIG.USER_KEY);
  window.location.href = './index.html';
}

// ── API Helpers with Retry ──────────────────────────────────
async function apiGet(endpoint, retries = 0) {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);

  try {
    const res = await fetch(`${CONFIG.API_BASE_URL}${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
      }
    });

    if (res.status === 401) {
      logout();
      throw new Error('Session expired. Please login again.');
    }

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || data.error || `HTTP ${res.status}`);
    }
    retryCount = 0;
    return data;
  } catch (err) {
    if (retries < MAX_RETRIES && (err.name === 'TypeError' || err.message.includes('network'))) {
      const delay = Math.pow(2, retries) * 1000;
      showToast(`Retrying... (${retries + 1}/${MAX_RETRIES})`, 'warning');
      await new Promise(r => setTimeout(r, delay));
      return apiGet(endpoint, retries + 1);
    }
    throw err;
  }
}

// ── Date Helpers ────────────────────────────────────────────
const ID_DAYS = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const ID_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

function formatDateID(date) {
  const d = new Date(date);
  return `${ID_DAYS[d.getDay()]}, ${d.getDate()} ${ID_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

function formatDateShort(date) {
  const d = new Date(date);
  return `${ID_DAYS[d.getDay()]}, ${d.getDate()} ${ID_MONTHS[d.getMonth()]}`;
}

function formatRupiah(num) {
  if (num === undefined || num === null || isNaN(num)) return 'Rp 0';
  return 'Rp ' + Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function formatNumber(num) {
  if (num === undefined || num === null || isNaN(num)) return '0';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function getDateRange(period) {
  const end = new Date();
  const start = new Date();
  switch (period) {
    case '7D': start.setDate(end.getDate() - 7); break;
    case '30D': start.setDate(end.getDate() - 30); break;
    case '90D': start.setDate(end.getDate() - 90); break;
  }
  return {
    start: start.toISOString().split('T')[0],
    end: end.toISOString().split('T')[0],
  };
}

// ── Loading State ───────────────────────────────────────────
function setDashboardLoading(loading) {
  isLoading = loading;
  const refreshBtn = $('refresh-btn');
  if (refreshBtn) {
    refreshBtn.disabled = loading;
    refreshBtn.innerHTML = loading
      ? `<span class="kt-spinner mr-2"></span> Refreshing...`
      : `<svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Refresh`;
  }

  // Show shimmer on stat cards
  const statValues = document.querySelectorAll('.stat-value');
  statValues.forEach(el => {
    if (loading) {
      el.dataset.originalText = el.textContent;
      el.innerHTML = '<span class="shimmer" style="display:inline-block;width:80%;height:1.5rem;"></span>';
    } else {
      // Remove shimmer, restore text will be done by update functions
    }
  });

  // Show chart loading overlays
  const salesLoading = $('sales-chart-loading');
  const paymentLoading = $('payment-chart-loading');
  if (salesLoading) salesLoading.classList.toggle('hidden', !loading);
  if (paymentLoading) paymentLoading.classList.toggle('hidden', !loading);
}

// ── Fetch Dashboard Data ────────────────────────────────────
async function fetchDashboardData() {
  if (isLoading) return;

  setDashboardLoading(true);

  // Use dateRange if set, otherwise use period
  let start, end;
  if (dateRange.start && dateRange.end) {
    start = dateRange.start;
    end = dateRange.end;
  } else {
    const range = getDateRange(currentPeriod);
    start = range.start;
    end = range.end;
  }

  const today = new Date().toISOString().split('T')[0];

  try {
    // Parallel fetch all endpoints
    const [salesSummary, bestSellers, dailySales, paymentSummary] = await Promise.all([
      apiGet(`/api/v1/analytics/sales-summary?start_date=${start}&end_date=${end}`).catch(err => {
        console.warn('Sales summary fetch failed:', err.message);
        return { data: {} };
      }),
      apiGet(`/api/v1/analytics/best-sellers?limit=5`).catch(err => {
        console.warn('Best sellers fetch failed:', err.message);
        return { data: [] };
      }),
      apiGet(`/api/v1/analytics/daily-sales?date=${today}`).catch(err => {
        console.warn('Daily sales fetch failed:', err.message);
        return { data: [] };
      }),
      apiGet(`/api/v1/analytics/payment-summary?date=${today}`).catch(err => {
        console.warn('Payment summary fetch failed:', err.message);
        return { data: [] };
      }),
    ]);

    updateStatCards(salesSummary.data || {});
    updateSalesChart(dailySales.data || [], start, end);
    updatePaymentChart(paymentSummary.data || []);
    updateBestSellersTable(bestSellers.data || []);

  } catch (err) {
    console.error('Dashboard load error:', err);
    showToast(err.message, 'error');
  } finally {
    setDashboardLoading(false);
  }
}

// ── Update Stat Cards ───────────────────────────────────────
function updateStatCards(data) {
  const gross = data.gross_revenue || 0;
  const net = data.net_revenue || 0;
  const transactions = data.total_transactions || 0;
  const aov = transactions > 0 ? Math.round(net / transactions) : 0;

  const stats = [
    { id: 'stat-gross', value: gross, prefix: 'Rp ', isMoney: true },
    { id: 'stat-net', value: net, prefix: 'Rp ', isMoney: true },
    { id: 'stat-orders', value: transactions, prefix: '', isMoney: false },
    { id: 'stat-aov', value: aov, prefix: 'Rp ', isMoney: true },
  ];

  stats.forEach(stat => {
    const valueEl = $(`${stat.id}-value`);
    if (valueEl) {
      valueEl.textContent = stat.prefix + (stat.isMoney ? formatNumber(stat.value) : formatNumber(stat.value));
      valueEl.classList.remove('shimmer');
    }
  });

  // Update trends (mock comparison since API doesn't provide historical comparison)
  updateTrend('stat-gross-trend', gross > 0 ? 12.5 : 0, true, 'vs last period');
  updateTrend('stat-net-trend', net > 0 ? 8.3 : 0, true, 'vs last period');
  updateTrend('stat-orders-trend', transactions > 0 ? 5.2 : 0, true, 'new this period');
  updateTrend('stat-aov-trend', aov > 0 ? -2.1 : 0, false, 'vs last period');
}

function updateTrend(elementId, percent, isUp, label) {
  const el = $(elementId);
  if (!el) return;

  const absPercent = Math.abs(percent);
  const colorClass = isUp ? 'text-green-600' : 'text-red-500';
  const arrowPath = isUp 
    ? 'M5 10l7-7m0 0l7 7m-7-7v18' 
    : 'M19 14l-7 7m0 0l-7-7m7 7V3';

  el.className = `flex items-center gap-1 text-xs font-semibold ${colorClass}`;
  el.innerHTML = `
    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${arrowPath}"/>
    </svg>
    ${absPercent}% ${label}
  `;
}

// ── Update Sales Trend Chart ────────────────────────────────
function updateSalesChart(data, startDate, endDate) {
  const ctx = $('sales-chart')?.getContext('2d');
  if (!ctx) return;

  // Generate labels for the date range
  const labels = [];
  const values = [];

  const start = new Date(startDate);
  const end = new Date(endDate);
  const dayDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

  // Build date map from API data
  const dataMap = {};
  if (Array.isArray(data)) {
    data.forEach(item => {
      if (item.sale_date) {
        dataMap[item.sale_date] = item.total_revenue || 0;
      }
    });
  }

  // Generate labels and values for each day in range
  for (let i = 0; i <= dayDiff && i <= 30; i++) {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    const dateStr = d.toISOString().split('T')[0];
    labels.push(formatDateShort(d));
    values.push(dataMap[dateStr] || 0);
  }

  if (salesChart) salesChart.destroy();

  salesChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Revenue',
        data: values,
        borderColor: '#16a34a',
        backgroundColor: 'rgba(22, 163, 74, 0.1)',
        borderWidth: 2.5,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: '#16a34a',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(17, 24, 39, 0.9)',
          titleColor: '#f9fafb',
          bodyColor: '#f9fafb',
          padding: 12,
          cornerRadius: 8,
          displayColors: false,
          callbacks: {
            label: (ctx) => `Revenue: ${formatRupiah(ctx.raw)}`,
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: '#9ca3af', font: { size: 11 } }
        },
        y: {
          grid: { color: 'rgba(0,0,0,0.05)' },
          ticks: {
            color: '#9ca3af',
            font: { size: 11 },
            callback: (val) => {
              if (val >= 1000000) return 'Rp ' + (val / 1000000).toFixed(1) + 'M';
              if (val >= 1000) return 'Rp ' + (val / 1000).toFixed(0) + 'K';
              return 'Rp ' + val;
            },
          },
          beginAtZero: true,
        }
      },
      interaction: { intersect: false, mode: 'index' },
    }
  });
}

// ── Update Payment Methods Chart ──────────────────────────
function updatePaymentChart(data) {
  const ctx = $('payment-chart')?.getContext('2d');
  if (!ctx) return;

  const colors = {
    cash: '#22c55e',
    qris: '#3b82f6',
    debit_card: '#a855f7',
    credit_card: '#f59e0b',
    transfer: '#06b6d4',
    e_wallet: '#ec4899',
  };

  const labels = [];
  const values = [];
  const bgColors = [];

  if (!Array.isArray(data) || data.length === 0) {
    // Empty state
    labels.push('No Data');
    values.push(1);
    bgColors.push('#e5e7eb');
  } else {
    data.forEach(item => {
      const method = item.payment_method || 'unknown';
      labels.push(method.replace(/_/g, ' ').toUpperCase());
      values.push(item.total_amount || 0);
      bgColors.push(colors[method] || '#6b7280');
    });
  }

  if (paymentChart) paymentChart.destroy();

  paymentChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: bgColors,
        borderWidth: 0,
        hoverOffset: 8,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            pointStyle: 'circle',
            padding: 16,
            color: '#6b7280',
            font: { size: 12 }
          }
        },
        tooltip: {
          backgroundColor: 'rgba(17, 24, 39, 0.9)',
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: (ctx) => {
              const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
              if (total === 0) return 'No data';
              const pct = ((ctx.raw / total) * 100).toFixed(1);
              return `${ctx.label}: ${pct}% (${formatRupiah(ctx.raw)})`;
            }
          }
        }
      }
    }
  });
}

// ── Update Best Sellers Table ───────────────────────────────
function updateBestSellersTable(data) {
  const tbody = $('best-sellers-body');
  if (!tbody) return;

  if (!Array.isArray(data) || data.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="py-8 text-center text-[var(--text-secondary)]">
          <svg class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
          </svg>
          <p class="text-sm font-medium">No sales data available</p>
          <p class="text-xs mt-1">Try adjusting the date range</p>
        </td>
      </tr>
    `;
    return;
  }

  const maxSales = Math.max(...data.map(d => d.total_sales || 0));
  const rankColors = ['bg-green-500', 'bg-amber-500', 'bg-blue-500', 'bg-gray-400', 'bg-gray-400'];

  tbody.innerHTML = data.map((item, index) => {
    const barWidth = maxSales > 0 ? (item.total_sales / maxSales) * 100 : 0;
    const rankColor = rankColors[index] || 'bg-gray-400';

    return `
      <tr class="border-b border-gray-100 hover:bg-gray-50/50 transition-colors">
        <td class="py-3 px-4">
          <span class="inline-flex items-center justify-center w-7 h-7 rounded-lg ${rankColor} text-white text-xs font-bold">
            #${index + 1}
          </span>
        </td>
        <td class="py-3 px-4">
          <div class="font-semibold text-gray-900 text-sm">${item.menu_name || 'Unknown'}</div>
        </td>
        <td class="py-3 px-4">
          <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
            ${item.category || 'Menu'}
          </span>
        </td>
        <td class="py-3 px-4 text-sm font-semibold text-gray-700">${formatNumber(item.total_quantity || 0)}</td>
        <td class="py-3 px-4 text-sm font-bold text-gray-900">${formatRupiah(item.total_sales)}</td>
        <td class="py-3 px-4">
          <div class="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
            <div class="h-full ${rankColor} rounded-full transition-all duration-500" style="width:${barWidth}%"></div>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

// ── Period Toggle ───────────────────────────────────────────
function setPeriod(period) {
  currentPeriod = period;
  dateRange = { start: '', end: '' }; // Reset custom range

  // Update button styles
  ['7D', '30D', '90D'].forEach(p => {
    const btn = $(`btn-${p.toLowerCase()}`);
    if (btn) {
      btn.classList.toggle('active', p === period);
    }
  });

  // Update date range label
  const range = getDateRange(period);
  const label = $(`date-range-label`);
  if (label) {
    label.textContent = `${formatDateShort(range.start)} - ${formatDateShort(range.end)}`;
  }

  fetchDashboardData();
}

// ── Date Range Picker ─────────────────────────────────────
function initDateRangePicker() {
  const pickerEl = $('date-range-picker');
  if (!pickerEl || typeof Litepicker === 'undefined') return;

  const today = new Date();
  const lastWeek = new Date();
  lastWeek.setDate(today.getDate() - 7);

  const picker = new Litepicker({
    element: pickerEl,
    singleMode: false,
    startDate: lastWeek,
    endDate: today,
    format: 'YYYY-MM-DD',
    numberOfMonths: 2,
    numberOfColumns: 2,
    tooltipText: {
      one: 'day',
      other: 'days',
    },
    setup: (picker) => {
      picker.on('selected', (date1, date2) => {
        const start = date1.format('YYYY-MM-DD');
        const end = date2.format('YYYY-MM-DD');
        dateRange = { start, end };
        currentPeriod = 'CUSTOM';

        // Reset period buttons
        ['7D', '30D', '90D'].forEach(p => {
          const btn = $(`btn-${p.toLowerCase()}`);
          if (btn) btn.classList.remove('active');
        });

        // Update label
        const label = $('date-range-label');
        if (label) {
          label.textContent = `${formatDateShort(start)} - ${formatDateShort(end)}`;
        }

        fetchDashboardData();
      });
    },
  });
}

// ── Toast Notifications ─────────────────────────────────────
function showToast(message, type = 'info') {
  const container = $('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const colors = {
    error: 'bg-red-50 border-red-200 text-red-700',
    success: 'bg-green-50 border-green-200 text-green-700',
    warning: 'bg-amber-50 border-amber-200 text-amber-700',
    info: 'bg-blue-50 border-blue-200 text-blue-700',
  };

  const icons = {
    error: 'M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    success: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
    warning: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
    info: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  };

  toast.className = `flex items-center gap-2 px-4 py-3 rounded-xl border shadow-lg ${colors[type]} kt-slide-in`;
  toast.innerHTML = `
    <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${icons[type]}"/>
    </svg>
    <span class="text-sm font-medium">${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-8px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ── Sidebar Toggle (Mobile) ─────────────────────────────────
function toggleSidebar() {
  const sidebar = $('sidebar');
  const overlay = $('sidebar-overlay');
  const isOpen = !sidebar.classList.contains('-translate-x-full');

  if (isOpen) {
    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');
  } else {
    sidebar.classList.remove('-translate-x-full');
    overlay.classList.remove('hidden');
  }
}

// ── Dark Mode Toggle ────────────────────────────────────────
function toggleDarkMode() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  localStorage.setItem('kopitiam_theme', isDark ? 'light' : 'dark');
}

function initDarkMode() {
  const saved = localStorage.getItem('kopitiam_theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (saved === 'dark' || (!saved && prefersDark)) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
}

// ── Setup Event Listeners ───────────────────────────────────
function setupEventListeners() {
  // Sidebar toggle
  const toggleBtn = $('btn-toggle-sidebar');
  if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);

  const overlay = $('sidebar-overlay');
  if (overlay) overlay.addEventListener('click', toggleSidebar);

  // Dark mode
  const darkModeBtn = $('btn-dark-mode');
  if (darkModeBtn) darkModeBtn.addEventListener('click', toggleDarkMode);

  // Logout
  const logoutBtn = $('btn-logout');
  if (logoutBtn) logoutBtn.addEventListener('click', logout);

  // Period buttons
  const btn7d = $('btn-7d');
  const btn30d = $('btn-30d');
  const btn90d = $('btn-90d');
  if (btn7d) btn7d.addEventListener('click', () => setPeriod('7D'));
  if (btn30d) btn30d.addEventListener('click', () => setPeriod('30D'));
  if (btn90d) btn90d.addEventListener('click', () => setPeriod('90D'));

  // Refresh button
  const refreshBtn = $('refresh-btn');
  if (refreshBtn) refreshBtn.addEventListener('click', fetchDashboardData);

  // View all button
  const viewAllBtn = $('btn-view-all');
  if (viewAllBtn) {
    viewAllBtn.addEventListener('click', () => {
      showToast('Full reports coming soon!', 'info');
    });
  }

  // Sidebar links
  document.querySelectorAll('.sidebar-link[data-page]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      if (page === 'dashboard') {
        // Already on dashboard
        showToast('Already on Dashboard', 'info');
      } else {
        showToast(`${page.charAt(0).toUpperCase() + page.slice(1)} page coming soon!`, 'info');
      }
    });
  });
}

// ── Initialization ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadConfig();
  initDarkMode();
  setupEventListeners();

  if (!checkAuth()) return;

  // Initialize date range picker
  initDateRangePicker();

  // Set initial period and fetch
  setPeriod('7D');

  // Auto refresh every 5 minutes
  autoRefreshInterval = setInterval(fetchDashboardData, 300000);
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
  if (autoRefreshInterval) {
    clearInterval(autoRefreshInterval);
  }
});

// Expose to global scope
window.logout = logout;
window.setPeriod = setPeriod;
window.toggleSidebar = toggleSidebar;
window.toggleDarkMode = toggleDarkMode;
window.fetchDashboardData = fetchDashboardData;
