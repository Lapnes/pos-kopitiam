/**
 * ============================================================
 * KopiTiam POS — Cashier Terminal (cashier.js)
 * Full-featured POS interface with menu, cart, and payment
 * ============================================================
 */

const CONFIG = {
  API_BASE_URL: 'http://localhost:8080',
  TOKEN_KEY: 'kopitiam_token',
  USER_KEY: 'kopitiam_user',
};

let menuItems = [];
let currentOrder = [];
let selectedCategory = 'all';
let selectedPayment = 'cash';
let isProcessing = false;

const $ = (id) => document.getElementById(id);

// ── Auth ────────────────────────────────────────────────────
function checkAuth() {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const user = JSON.parse(localStorage.getItem(CONFIG.USER_KEY) || '{}');
  if (!token) {
    window.location.href = './index.html';
    return false;
  }
  if (user.name) {
    const elName = $('user-name');
    const elRole = $('user-role');
    const elInitial = $('user-initial');
    if (elName) elName.textContent = user.name;
    if (elRole) elRole.textContent = user.role || 'Cashier';
    if (elInitial) elInitial.textContent = (user.name || 'C').charAt(0).toUpperCase();
  }
  return token;
}

function logout() {
  localStorage.removeItem(CONFIG.TOKEN_KEY);
  localStorage.removeItem(CONFIG.USER_KEY);
  window.location.href = './index.html';
}

// ── API ─────────────────────────────────────────────────────
async function apiGet(endpoint) {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const res = await fetch(`${CONFIG.API_BASE_URL}${endpoint}`, {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
  });
  if (res.status === 401) { logout(); throw new Error('Session expired'); }
  const data = await res.json();
  if (!res.ok || !data.success) throw new Error(data.message || 'Request failed');
  return data;
}

async function apiPost(endpoint, body) {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const res = await fetch(`${CONFIG.API_BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(body)
  });
  if (res.status === 401) { logout(); throw new Error('Session expired'); }
  const data = await res.json();
  if (!res.ok || !data.success) throw new Error(data.message || 'Request failed');
  return data;
}

// ── Formatters ────────────────────────────────────────────────
function formatRupiah(num) {
  if (!num || isNaN(num)) return 'Rp 0';
  return 'Rp ' + Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function formatNumber(num) {
  if (!num || isNaN(num)) return '0';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

// ── Menu ──────────────────────────────────────────────────────
async function loadMenu() {
  try {
    const data = await apiGet('/api/v1/menu?limit=100');
    menuItems = data.data || [];
    renderMenu();
  } catch (err) {
    showToast('Failed to load menu: ' + err.message, 'error');
    // Fallback demo data
    menuItems = [
      { id: 1, name: 'Espresso', price: 18000, category: 'coffee', image_url: '' },
      { id: 2, name: 'Cappuccino', price: 25000, category: 'coffee', image_url: '' },
      { id: 3, name: 'Latte', price: 28000, category: 'coffee', image_url: '' },
      { id: 4, name: 'Americano', price: 22000, category: 'coffee', image_url: '' },
      { id: 5, name: 'Green Tea', price: 20000, category: 'tea', image_url: '' },
      { id: 6, name: 'Thai Tea', price: 24000, category: 'tea', image_url: '' },
      { id: 7, name: 'Croissant', price: 15000, category: 'food', image_url: '' },
      { id: 8, name: 'Sandwich', price: 35000, category: 'food', image_url: '' },
      { id: 9, name: 'Cheesecake', price: 30000, category: 'dessert', image_url: '' },
      { id: 10, name: 'Tiramisu', price: 32000, category: 'dessert', image_url: '' },
    ];
    renderMenu();
  }
}

function renderMenu() {
  const grid = $('menu-grid');
  const search = ($('menu-search')?.value || '').toLowerCase();

  const filtered = menuItems.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = !search || (item.name || '').toLowerCase().includes(search);
    return matchesCategory && matchesSearch;
  });

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div class="col-span-full py-12 text-center text-[var(--text-secondary)]">
        <svg class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <p class="text-sm font-medium">No items found</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = filtered.map(item => `
    <div class="menu-card p-3" data-id="${item.id}" onclick="addToOrder(${item.id})">
      <div class="w-full h-24 rounded-lg bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center mb-3 text-3xl">
        ${getCategoryEmoji(item.category)}
      </div>
      <h4 class="font-semibold text-sm text-[var(--text-primary)] truncate">${item.name}</h4>
      <p class="text-xs text-[var(--text-secondary)] mt-0.5">${item.category || 'Menu'}</p>
      <p class="text-sm font-bold text-kopitiam-600 mt-2">${formatRupiah(item.price)}</p>
    </div>
  `).join('');
}

function getCategoryEmoji(cat) {
  const map = { coffee: '☕', tea: '🍵', food: '🥐', dessert: '🍰' };
  return map[cat] || '🍽️';
}

// ── Order Management ────────────────────────────────────────
function addToOrder(itemId) {
  const item = menuItems.find(i => i.id === itemId);
  if (!item) return;

  const existing = currentOrder.find(o => o.id === itemId);
  if (existing) {
    existing.quantity += 1;
  } else {
    currentOrder.push({ ...item, quantity: 1, notes: '' });
  }
  renderOrder();
  showToast(`${item.name} added`, 'success');
}

function updateQuantity(itemId, delta) {
  const item = currentOrder.find(o => o.id === itemId);
  if (!item) return;

  item.quantity += delta;
  if (item.quantity <= 0) {
    currentOrder = currentOrder.filter(o => o.id !== itemId);
  }
  renderOrder();
}

function clearOrder() {
  currentOrder = [];
  renderOrder();
}

function renderOrder() {
  const container = $('order-items');
  const emptyEl = $('empty-order');

  if (currentOrder.length === 0) {
    container.innerHTML = '';
    container.appendChild(emptyEl);
    emptyEl.classList.remove('hidden');
  } else {
    if (emptyEl) emptyEl.classList.add('hidden');
    container.innerHTML = currentOrder.map(item => `
      <div class="order-item">
        <div class="flex items-start justify-between mb-2">
          <div>
            <h4 class="font-semibold text-sm text-[var(--text-primary)]">${item.name}</h4>
            <p class="text-xs text-[var(--text-secondary)]">${formatRupiah(item.price)} each</p>
          </div>
          <button onclick="updateQuantity(${item.id}, -1)" class="quantity-btn minus">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"/></svg>
          </button>
        </div>
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <button onclick="updateQuantity(${item.id}, -1)" class="quantity-btn minus">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"/></svg>
            </button>
            <span class="text-sm font-bold w-6 text-center">${item.quantity}</span>
            <button onclick="updateQuantity(${item.id}, 1)" class="quantity-btn plus">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            </button>
          </div>
          <span class="text-sm font-bold text-kopitiam-600">${formatRupiah(item.price * item.quantity)}</span>
        </div>
      </div>
    `).join('');
  }

  updateTotals();
}

function updateTotals() {
  const subtotal = currentOrder.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = Math.round(subtotal * 0.1);
  const total = subtotal + tax;

  $('subtotal').textContent = formatRupiah(subtotal);
  $('tax').textContent = formatRupiah(tax);
  $('total').textContent = formatRupiah(total);
  $('charge-text').textContent = `Charge ${formatRupiah(total)}`;
}

// ── Payment ─────────────────────────────────────────────────
function setPayment(method) {
  selectedPayment = method;
  document.querySelectorAll('.payment-method-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.payment === method);
  });
}

async function processPayment() {
  if (currentOrder.length === 0) {
    showToast('Add items to order first', 'warning');
    return;
  }
  if (isProcessing) return;

  isProcessing = true;
  const btn = $('btn-charge');
  btn.disabled = true;
  btn.innerHTML = '<span class="kt-spinner mr-2"></span> Processing...';

  try {
    const subtotal = currentOrder.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = Math.round(subtotal * 0.1);
    const total = subtotal + tax;

    const orderData = {
      items: currentOrder.map(item => ({
        menu_item_id: item.id,
        quantity: item.quantity,
        price: item.price,
        notes: item.notes || ''
      })),
      payment_method: selectedPayment,
      tax_amount: tax,
      total_amount: total,
    };

    const res = await apiPost('/api/v1/orders', orderData);

    // Show receipt
    $('receipt-order-id').textContent = `#${res.data?.id || '0001'}`;
    $('receipt-payment').textContent = selectedPayment.toUpperCase();
    $('receipt-total').textContent = formatRupiah(total);
    $('payment-modal').classList.remove('hidden');
    $('payment-modal').classList.add('flex');

    showToast('Payment successful!', 'success');
  } catch (err) {
    showToast('Payment failed: ' + err.message, 'error');
    isProcessing = false;
    btn.disabled = false;
    btn.innerHTML = `<span id="charge-text">Charge ${$('total').textContent}</span>`;
  }
}

function closePaymentModal() {
  $('payment-modal').classList.add('hidden');
  $('payment-modal').classList.remove('flex');
  currentOrder = [];
  renderOrder();
  isProcessing = false;
  const btn = $('btn-charge');
  btn.disabled = false;
  btn.innerHTML = '<span id="charge-text">Charge Rp 0</span>';
}

// ── Toast ─────────────────────────────────────────────────────
function showToast(message, type = 'info') {
  const container = $('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const colors = {
    error: 'bg-red-50 border-red-200 text-red-700',
    success: 'bg-green-50 border-green-200 text-green-700',
    warning: 'bg-amber-50 border-amber-200 text-amber-700',
    info: 'bg-blue-50 border-blue-200 text-blue-700',
  };
  const icons = {
    error: 'M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    success: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
    warning: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
    info: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  };

  toast.className = `flex items-center gap-2 px-4 py-3 rounded-xl border shadow-lg ${colors[type]} kt-slide-in`;
  toast.innerHTML = `
    <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${icons[type]}"/>
    </svg>
    <span class="text-sm font-medium">${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-8px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── Dark Mode ───────────────────────────────────────────────
function toggleDarkMode() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  localStorage.setItem('kopitiam_theme', isDark ? 'light' : 'dark');
}

function initDarkMode() {
  const saved = localStorage.getItem('kopitiam_theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (saved === 'dark' || (!saved && prefersDark)) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
}

// ── Event Listeners ─────────────────────────────────────────
function setupEventListeners() {
  // Category filters
  document.querySelectorAll('.category-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedCategory = btn.dataset.category;
      document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderMenu();
    });
  });

  // Search
  const searchInput = $('menu-search');
  if (searchInput) {
    searchInput.addEventListener('input', renderMenu);
  }

  // Payment methods
  document.querySelectorAll('.payment-method-btn').forEach(btn => {
    btn.addEventListener('click', () => setPayment(btn.dataset.payment));
  });

  // Action buttons
  $('btn-charge')?.addEventListener('click', processPayment);
  $('btn-clear')?.addEventListener('click', clearOrder);
  $('btn-new-order')?.addEventListener('click', closePaymentModal);
  $('btn-dark-mode')?.addEventListener('click', toggleDarkMode);
  $('btn-logout')?.addEventListener('click', logout);

  // Close modal on backdrop click
  $('payment-modal')?.addEventListener('click', (e) => {
    if (e.target === $('payment-modal')) closePaymentModal();
  });
}

// ── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initDarkMode();
  setupEventListeners();
  if (!checkAuth()) return;
  loadMenu();
});

// Expose to global
window.addToOrder = addToOrder;
window.updateQuantity = updateQuantity;
window.clearOrder = clearOrder;
window.setPayment = setPayment;
window.processPayment = processPayment;
window.closePaymentModal = closePaymentModal;
window.logout = logout;
window.toggleDarkMode = toggleDarkMode;
