/**
 * ============================================================
 * KopiTiam POS — Kitchen Display System (kitchen.js)
 * Real-time order management for kitchen staff
 * ============================================================
 */

const CONFIG = {
  API_BASE_URL: 'http://localhost:8080',
  TOKEN_KEY: 'kopitiam_token',
  USER_KEY: 'kopitiam_user',
};

let orders = [];
let currentFilter = 'all';
let refreshInterval = null;
let orderTimers = {};

const $ = (id) => document.getElementById(id);

// ── Auth ────────────────────────────────────────────────────
function checkAuth() {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const user = JSON.parse(localStorage.getItem(CONFIG.USER_KEY) || '{}');
  if (!token) {
    window.location.href = './index.html';
    return false;
  }
  if (user.name) {
    const elName = $('user-name');
    const elRole = $('user-role');
    const elInitial = $('user-initial');
    if (elName) elName.textContent = user.name;
    if (elRole) elRole.textContent = user.role || 'Kitchen';
    if (elInitial) elInitial.textContent = (user.name || 'K').charAt(0).toUpperCase();
  }
  return token;
}

function logout() {
  localStorage.removeItem(CONFIG.TOKEN_KEY);
  localStorage.removeItem(CONFIG.USER_KEY);
  window.location.href = './index.html';
}

// ── API ─────────────────────────────────────────────────────
async function apiGet(endpoint) {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const res = await fetch(`${CONFIG.API_BASE_URL}${endpoint}`, {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
  });
  if (res.status === 401) { logout(); throw new Error('Session expired'); }
  const data = await res.json();
  if (!res.ok || !data.success) throw new Error(data.message || 'Request failed');
  return data;
}

async function apiPatch(endpoint, body) {
  const token = localStorage.getItem(CONFIG.TOKEN_KEY);
  const res = await fetch(`${CONFIG.API_BASE_URL}${endpoint}`, {
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(body)
  });
  if (res.status === 401) { logout(); throw new Error('Session expired'); }
  const data = await res.json();
  if (!res.ok || !data.success) throw new Error(data.message || 'Request failed');
  return data;
}

// ── Formatters ──────────────────────────────────────────────
function formatRupiah(num) {
  if (!num || isNaN(num)) return 'Rp 0';
  return 'Rp ' + Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function formatElapsed(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// ── Orders ──────────────────────────────────────────────────
async function loadOrders() {
  try {
    const data = await apiGet('/api/v1/orders?status=pending,preparing,ready&limit=50');
    orders = data.data || [];
    renderOrders();
    updateCounts();
  } catch (err) {
    showToast('Failed to load orders: ' + err.message, 'error');
    // Fallback demo data
    orders = [
      {
        id: 1001,
        order_number: 'ORD-001',
        status: 'pending',
        items: [
          { menu_item_name: 'Espresso', quantity: 2, notes: 'Extra hot' },
          { menu_item_name: 'Croissant', quantity: 1, notes: '' }
        ],
        total_amount: 51000,
        created_at: new Date(Date.now() - 120000).toISOString(),
        order_type: 'dine_in',
        table_number: 'A3'
      },
      {
        id: 1002,
        order_number: 'ORD-002',
        status: 'preparing',
        items: [
          { menu_item_name: 'Cappuccino', quantity: 1, notes: 'Oat milk' },
          { menu_item_name: 'Latte', quantity: 2, notes: '' },
          { menu_item_name: 'Cheesecake', quantity: 1, notes: '' }
        ],
        total_amount: 108000,
        created_at: new Date(Date.now() - 300000).toISOString(),
        order_type: 'takeaway',
        table_number: null
      },
      {
        id: 1003,
        order_number: 'ORD-003',
        status: 'ready',
        items: [
          { menu_item_name: 'Green Tea', quantity: 1, notes: 'Less sugar' }
        ],
        total_amount: 20000,
        created_at: new Date(Date.now() - 600000).toISOString(),
        order_type: 'dine_in',
        table_number: 'B1'
      }
    ];
    renderOrders();
    updateCounts();
  }
}

function updateCounts() {
  const counts = { pending: 0, preparing: 0, ready: 0, completed: 0 };
  orders.forEach(o => { if (counts[o.status] !== undefined) counts[o.status]++; });

  $('count-pending').textContent = counts.pending;
  $('count-preparing').textContent = counts.preparing;
  $('count-ready').textContent = counts.ready;
  $('count-completed').textContent = counts.completed;
}

function renderOrders() {
  const grid = $('orders-grid');

  const filtered = currentFilter === 'all' 
    ? orders 
    : orders.filter(o => o.status === currentFilter);

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div class="col-span-full py-12 text-center text-[var(--text-secondary)]">
        <svg class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
        </svg>
        <p class="text-sm font-medium">No ${currentFilter} orders</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = filtered.map(order => {
    const elapsed = Math.floor((Date.now() - new Date(order.created_at)) / 1000);
    const isUrgent = elapsed > 600 && order.status !== 'ready' && order.status !== 'completed';
    const statusLabels = { pending: 'Pending', preparing: 'Preparing', ready: 'Ready', completed: 'Completed' };
    const nextActions = {
      pending: { label: 'Start Preparing', action: 'preparing', class: 'kds-btn-primary' },
      preparing: { label: 'Mark Ready', action: 'ready', class: 'kds-btn-success' },
      ready: { label: 'Complete', action: 'completed', class: 'kds-btn-secondary' }
    };
    const next = nextActions[order.status];

    return `
      <div class="order-card status-${order.status} kt-fade-in">
        <div class="flex items-start justify-between mb-3">
          <div>
            <div class="flex items-center gap-2 mb-1">
              <h3 class="font-bold text-lg text-[var(--text-primary)]">${order.order_number || `#${order.id}`}</h3>
              <span class="status-badge ${order.status}">${statusLabels[order.status]}</span>
            </div>
            <div class="flex items-center gap-3 text-xs text-[var(--text-secondary)]">
              <span class="flex items-center gap-1">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <span class="timer ${isUrgent ? 'urgent' : ''}" data-order-id="${order.id}" data-created="${order.created_at}">${formatElapsed(elapsed)}</span>
              </span>
              ${order.table_number ? `<span class="flex items-center gap-1"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg> Table ${order.table_number}</span>` : '<span class="flex items-center gap-1"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg> Takeaway</span>'}
            </div>
          </div>
          <span class="text-sm font-bold text-kopitiam-600">${formatRupiah(order.total_amount)}</span>
        </div>

        <div class="space-y-2 mb-4">
          ${(order.items || []).map(item => `
            <div class="flex items-start justify-between text-sm">
              <div class="flex items-start gap-2">
                <span class="font-bold text-kopitiam-600 min-w-[1.5rem]">${item.quantity}x</span>
                <div>
                  <span class="font-medium text-[var(--text-primary)]">${item.menu_item_name || item.name || 'Item'}</span>
                  ${item.notes ? `<p class="text-xs text-amber-600 mt-0.5">📝 ${item.notes}</p>` : ''}
                </div>
              </div>
            </div>
          `).join('')}
        </div>

        <div class="flex gap-2 pt-3 border-t border-[var(--border-color)]">
          ${next ? `
            <button onclick="updateOrderStatus(${order.id}, '${next.action}')" class="${next.class} kds-btn flex-1 justify-center">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
              ${next.label}
            </button>
          ` : ''}
          ${order.status !== 'completed' ? `
            <button onclick="cancelOrder(${order.id})" class="kds-btn kds-btn-secondary">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

// ── Order Actions ───────────────────────────────────────────
async function updateOrderStatus(orderId, newStatus) {
  try {
    await apiPatch(`/api/v1/orders/${orderId}/status`, { status: newStatus });
    showToast(`Order marked as ${newStatus}`, 'success');
    loadOrders();
  } catch (err) {
    showToast('Failed to update: ' + err.message, 'error');
  }
}

async function cancelOrder(orderId) {
  if (!confirm('Cancel this order?')) return;
  try {
    await apiPatch(`/api/v1/orders/${orderId}/status`, { status: 'cancelled' });
    showToast('Order cancelled', 'warning');
    loadOrders();
  } catch (err) {
    showToast('Failed to cancel: ' + err.message, 'error');
  }
}

// ── Timer Update ────────────────────────────────────────────
function startTimerUpdates() {
  setInterval(() => {
    document.querySelectorAll('.timer[data-created]').forEach(el => {
      const created = new Date(el.dataset.created);
      const elapsed = Math.floor((Date.now() - created) / 1000);
      el.textContent = formatElapsed(elapsed);

      const orderCard = el.closest('.order-card');
      if (elapsed > 600 && orderCard && !orderCard.classList.contains('status-ready') && !orderCard.classList.contains('status-completed')) {
        el.classList.add('urgent');
      }
    });
  }, 1000);
}

// ── Toast ───────────────────────────────────────────────────
function showToast(message, type = 'info') {
  const container = $('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const colors = {
    error: 'bg-red-50 border-red-200 text-red-700',
    success: 'bg-green-50 border-green-200 text-green-700',
    warning: 'bg-amber-50 border-amber-200 text-amber-700',
    info: 'bg-blue-50 border-blue-200 text-blue-700',
  };
  const icons = {
    error: 'M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    success: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
    warning: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
    info: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  };

  toast.className = `flex items-center gap-2 px-4 py-3 rounded-xl border shadow-lg ${colors[type]} kt-slide-in`;
  toast.innerHTML = `
    <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${icons[type]}"/>
    </svg>
    <span class="text-sm font-medium">${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-8px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── Dark Mode ───────────────────────────────────────────────
function toggleDarkMode() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  localStorage.setItem('kopitiam_theme', isDark ? 'light' : 'dark');
}

function initDarkMode() {
  const saved = localStorage.getItem('kopitiam_theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (saved === 'dark' || (!saved && prefersDark)) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
}

// ── Event Listeners ─────────────────────────────────────────
function setupEventListeners() {
  document.querySelectorAll('.category-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      currentFilter = btn.dataset.filter;
      document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderOrders();
    });
  });

  $('btn-dark-mode')?.addEventListener('click', toggleDarkMode);
  $('btn-logout')?.addEventListener('click', logout);
}

// ── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initDarkMode();
  setupEventListeners();
  if (!checkAuth()) return;
  loadOrders();
  startTimerUpdates();

  // Auto refresh every 30 seconds
  refreshInterval = setInterval(loadOrders, 30000);
});

window.updateOrderStatus = updateOrderStatus;
window.cancelOrder = cancelOrder;
window.logout = logout;
window.toggleDarkMode = toggleDarkMode;
